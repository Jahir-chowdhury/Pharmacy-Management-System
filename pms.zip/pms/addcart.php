<?php
	
	if (isset($_GET['add']))
		{	
			echo 'OK';
		}

?>